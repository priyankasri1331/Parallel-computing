#!/bin/bash

g++ -o my inverse.cpp

#if($? == 0)
./my 256

#g++ -o ap rinverse.cpp

