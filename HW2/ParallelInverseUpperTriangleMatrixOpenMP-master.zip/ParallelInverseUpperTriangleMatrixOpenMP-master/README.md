# ParallelInverseUpperTriangleMatrixOpenMP
Dense Matrix Computations with OpenMP. Calculate the inverse of an upper triangular matrix in parallel.
