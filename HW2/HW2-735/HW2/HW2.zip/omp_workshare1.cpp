#include <iostream>
#include <stdio.h>
#include <omp.h> //Header file for openMP workstation.

#define CHUNKSIZE 10
#define n 100

using namespace std;

int main(int argc ,char ** argv)
{
//Initialization for splitting up workloads across various number of threads.


int nthreads, i, tid,chunk;
float a[n],b[n],c[n];

for(i=0;i<n;i++) a[i] = b[i] =i*1.0;
chunk = CHUNKSIZE;

#pragma omp parallel shared(a,b,c,nthreads,chunk) private(i,tid)
{

tid = omp_get_thread_num();
if(tid==0)
{
nthreads = omp_get_num_threads();
cout<<"Number of threads :"<<nthreads<<endl;
}
printf("Thread %d starging \n",tid);

//Parallelize the for loop by assinging each individual chunk of operation to seperate number of threads.
#pragma omp for schedule(static,chunk)
for(i=0;i<n;i++)
{

c[i] = a[i]+b[i];
printf("Thread id %d, c[%d] = %f \n",tid,i,c[i]);
}
}
}
