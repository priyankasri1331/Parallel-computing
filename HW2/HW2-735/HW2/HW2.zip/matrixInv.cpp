//C++ Program for testing out the benefits of parallelization using OpenMP.

#include <iostream>
#include <stdlib.h>
#include <vector>
#include <omp.h>
using namespace std;
// g++ -W -o output_name source.cpp -fopenmp

//flag for openmp in GCC ->  -fopenmp whereas for icc -> -qopenmp
//Compiler Directives OpenMP \
	#pragma omp directive_name [clauses. ..]
/*
*#pragma omp -> is mandatory
*Directrive ->for,static, private and ...
*Clauses -> ?
*/

// parallel -> makes the next block of structured code runs in parallel, construct works with function too
//Clauses are different from parallels.
vector<int> testVec{0,1,2,3,};


int  main(int argc, char** argv)
{
	
	int nthreads,tid;
	for(int j = 0;j<testVec.size();j++) cout<<testVec.at(j)<<endl;	
	#pragma omp parallel private(nthreads,tid)//Forks team of threads where each thread has own ptid.
	{
		
		tid = omp_get_thread_num(); //Gets the thread num currently executing it.
		//Code here runs in parallel.
		cout<<" Hello world from thread = "<<tid<<endl;

		//Only Master thread runs this:
		if(tid == 0) 
			{
				nthreads = omp_get_num_threads();	
				cout<<" From Master Thread id = "<<tid<<"numthreads = "<<nthreads<<endl;
			}


	} //all threads join Master thread end of parallelism.

	return EXIT_SUCCESS;//Macro for returning on sucessful completion.
}
