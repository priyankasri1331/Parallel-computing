export OMP_NUM_THREADS=8
./matInv.out

